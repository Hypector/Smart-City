from django.contrib import admin
from homepage.models import Attraction

admin.site.register(Attraction)

# Register your models here.
