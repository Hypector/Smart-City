from django.apps import AppConfig


class CreateuserConfig(AppConfig):
    name = 'createuser'
